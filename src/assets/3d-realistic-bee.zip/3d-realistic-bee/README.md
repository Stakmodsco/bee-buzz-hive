# 3D Realistic Bee

A Pen created on CodePen.

Original URL: [https://codepen.io/DenDionigi/pen/QwWYedd](https://codepen.io/DenDionigi/pen/QwWYedd).

Webgl Bee made using ThreeJs