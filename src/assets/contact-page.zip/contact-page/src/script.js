document.addEventListener("DOMContentLoaded", function() {
    const checkbox = document.getElementById("show-contact");
    const inputs = document.querySelectorAll("#name, #email, #message");
    let flipTimer;

    checkbox.addEventListener("change", function() {
        if (checkbox.checked) {
            // Start timer when form shows
            flipTimer = setTimeout(() => {
                checkbox.checked = false;
            }, 10000); // auto flip back in 10s
        } else {
            // Stop timer if card flips back
            clearTimeout(flipTimer);
        }
    });

    // Cancel timer if the user starts typing
    inputs.forEach(input => {
        input.addEventListener("input", () => {
            clearTimeout(flipTimer);
        });
    });
});
